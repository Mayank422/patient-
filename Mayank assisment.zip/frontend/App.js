
// Frontend: React.js + Tailwind CSS

import React, { useState, useEffect } from "react";
import axios from "axios";
import "tailwindcss/tailwind.css";

const App = () => {
  const [patients, setPatients] = useState([]);
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [tests, setTests] = useState([]);
  
  useEffect(() => {
    axios.get("http://localhost:5000/patients").then((response) => {
      setPatients(response.data);
    });
  }, []);

  const addPatient = async () => {
    const newPatient = { name, age: parseInt(age), tests };
    const response = await axios.post("http://localhost:5000/patients", newPatient);
    setPatients([...patients, response.data]);
    setName("");
    setAge("");
    setTests([]);
  };

  return (
    <div className="container mx-auto p-5">
      <h1 className="text-2xl font-bold mb-4">Pathology Lab Management</h1>
      <div className="mb-4">
        <input 
          type="text" 
          placeholder="Patient Name" 
          className="border p-2 mr-2"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input 
          type="number" 
          placeholder="Age" 
          className="border p-2 mr-2"
          value={age}
          onChange={(e) => setAge(e.target.value)}
        />
        <button className="bg-blue-500 text-white p-2" onClick={addPatient}>Add Patient</button>
      </div>
      <h2 className="text-xl font-semibold">Patients List</h2>
      <ul className="mt-4">
        {patients.map((patient) => (
          <li key={patient._id} className="border p-2 my-2">
            {patient.name} (Age: {patient.age})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
